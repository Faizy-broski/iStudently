"use client";

import { useState, useEffect, useMemo } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, Eye, Edit, MoreHorizontal, ChevronLeft, ChevronRight, Loader2, RefreshCw } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationPrevious,
  PaginationNext,
} from "@/components/ui/pagination";
import { type Parent } from "@/lib/api/parents";
import { useParents } from "@/hooks/useParents";
import { useDebouncedValue } from "@/hooks/useDebouncedValue";
import { toast } from "sonner";
import { Lock } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { EditCredentialsModal } from "@/components/admin/EditCredentialsModal";
import { useTranslations } from "next-intl";

export default function ParentInfoPage() {
  const router = useRouter();
  const t = useTranslations("parents");
  const { user } = useAuth();
  const schoolId = user?.school_id || '';
  const [showCredentialsModal, setShowCredentialsModal] = useState(false);
  const [credentialsData, setCredentialsData] = useState<{ id: string, name: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [showInactive, setShowInactive] = useState(false);
  const [selectedParent, setSelectedParent] = useState<Parent | null>(null);
  const [showChildrenDialog, setShowChildrenDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);

  const itemsPerPage = 10;

  // Debounce search query to avoid excessive API calls
  const debouncedSearch = useDebouncedValue(searchQuery, 500);

  // Use SWR hook for data fetching with caching
  const { parents, total, totalPages, loading, error, refresh } = useParents({
    page: currentPage,
    limit: itemsPerPage,
    search: debouncedSearch,
  });

  // Show error toast if there's an error, but only after initial mount
  // This prevents transient errors during component remount from showing
  const [hasInitialized, setHasInitialized] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => setHasInitialized(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (error && hasInitialized) {
      toast.error(error);
    }
  }, [error, hasInitialized]);

  // Refresh data on mount to ensure fresh data
  useEffect(() => {
    if (refresh) {
      refresh();
    }
  }, []); // Empty deps array = runs once on mount

  const handleShowChildren = (parent: Parent) => {
    setSelectedParent(parent);
    setShowChildrenDialog(true);
  };

  const handleViewDetails = (parent: Parent) => {
    router.push(`/admin/parents/${parent.id}`);
  };

  const handleEditParent = (parent: Parent) => {
    // Navigate to dedicated edit page
    router.push(`/admin/parents/${parent.id}/edit`);
  };

  const getStatusBadge = (isActive: boolean) => {
    return isActive ? (
      <Badge className="bg-green-100 text-green-800 hover:bg-green-100">{t("active")}</Badge>
    ) : (
      <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">{t("inactive")}</Badge>
    );
  };

  // Filter by active/inactive status (client-side)
  const filteredParents = useMemo(() => {
    if (showInactive) return parents;
    return parents.filter(p => p.profile?.is_active !== false);
  }, [parents, showInactive]);

  const renderChildren = (parent: Parent) => {
    const children = parent.children || [];

    if (children.length === 0) {
      return <span className="text-sm text-muted-foreground">{t("noChildren")}</span>;
    }

    if (children.length === 1) {
      const child = children[0];
      const fullName = `${child.profile?.first_name || ''} ${child.profile?.last_name || ''}`.trim();
      return (
        <div className="flex flex-col">
          <span className="text-sm font-medium">{fullName || t("na")}</span>
          <span className="text-xs text-muted-foreground">
            {child.student_number} • {child.grade_level || t("na")}
          </span>
        </div>
      );
    }

    const firstChild = children[0];
    const fullName = `${firstChild.profile?.first_name || ''} ${firstChild.profile?.last_name || ''}`.trim();
    return (
      <div className="flex flex-col">
        <span className="text-sm font-medium">{fullName || t("na")}</span>
        <button
          onClick={() => handleShowChildren(parent)}
          className="text-xs text-blue-600 hover:text-blue-800 hover:underline text-left"
        >
          +{children.length - 1} {t("more")}
        </button>
      </div>
    );
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold bg-linear-to-r from-[#57A3CC] to-[#022172] bg-clip-text text-transparent">
            {t("parentInformationTitle")}
          </h1>
          <p className="text-sm md:text-base text-muted-foreground mt-2">
            {t("parentInformationSubtitle")}
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            refresh();
            toast.success(t("toasts.refreshingList"));
          }}
          disabled={loading}
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          {t("refresh")}
        </Button>
      </div>

      {/* Search Bar */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t("searchPlaceholder")}
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="pl-10"
              />
            </div>
            <label className="flex items-center gap-2 text-sm text-muted-foreground cursor-pointer">
              <input
                type="checkbox"
                checked={showInactive}
                onChange={(e) => setShowInactive(e.target.checked)}
                className="rounded border-gray-300"
              />
              Show inactive
            </label>
          </div>
        </CardContent>
      </Card>

      {/* Results Summary */}
      <div className="text-sm text-muted-foreground">
        {loading ? (
          <span>{t("loading")}</span>
        ) : (
          <span>{t("showingResults", { from: parents.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0, to: Math.min(currentPage * itemsPerPage, total), total })}</span>
        )}
      </div>

      {/* Parents Table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-linear-to-r from-[#57A3CC]/10 to-[#022172]/10">
                    <TableHead>{t("table.parentName")}</TableHead>
                    <TableHead>{t("table.contact")}</TableHead>
                    <TableHead>{t("table.occupation")}</TableHead>
                    <TableHead>{t("table.children")}</TableHead>
                    <TableHead>{t("table.status")}</TableHead>
                    <TableHead className="text-right">{t("table.actions")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredParents.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                        {t("noParentsFound")}
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredParents.map((parent) => {
                      const fullName = `${parent.profile?.first_name || ''} ${parent.profile?.last_name || ''}`.trim();
                      const initials = fullName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

                      return (
                        <TableRow 
                          key={parent.id}
                          className="hover:bg-muted/50 cursor-pointer"
                          onClick={() => handleViewDetails(parent)}
                        >
                          <TableCell className="max-w-sm">
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-full bg-linear-to-r from-[#57A3CC] to-[#022172] flex items-center justify-center text-white font-semibold shrink-0">
                                {initials || t("na")}
                              </div>
                              <div className="min-w-0 flex-1">
                                <div className="font-medium truncate">{fullName || t("na")}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="max-w-xs">
                            <div className="text-sm space-y-1 min-w-0">
                              <div className="truncate">{parent.profile?.email || t("na")}</div>
                              <div className="text-muted-foreground truncate">{parent.profile?.phone || t("na")}</div>
                            </div>
                          </TableCell>
                          <TableCell className="max-w-xs">
                            <span className="text-sm truncate block">{parent.occupation || t("na")}</span>
                          </TableCell>
                          <TableCell>{renderChildren(parent)}</TableCell>
                          <TableCell>{getStatusBadge(parent.profile?.is_active || false)}</TableCell>
                          <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>{t("actions.menu")}</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onClick={() => handleViewDetails(parent)}>
                                  <Eye className="mr-2 h-4 w-4" />
                                  {t("actions.viewDetails")}
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => {
                                  setCredentialsData({
                                    id: parent.id,
                                    name: `${parent.profile?.first_name || ''} ${parent.profile?.last_name || ''}`
                                  });
                                  setShowCredentialsModal(true);
                                }}>
                                  <Lock className="mr-2 h-4 w-4" />
                                  {t("actions.editCredentials")}
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleEditParent(parent)}>
                                  <Edit className="mr-2 h-4 w-4" />
                                  {t("actions.editParent")}
                                </DropdownMenuItem>
                                {parent.children && parent.children.length > 0 && (
                                  <DropdownMenuItem onClick={() => handleShowChildren(parent)}>
                                    <Eye className="mr-2 h-4 w-4" />
                                    {t("actions.viewAllChildren")}
                                  </DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      )
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Pagination */}
      <div className="mt-6 flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {t("showingResults", { from: parents.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0, to: Math.min(currentPage * itemsPerPage, total), total })}
        </p>
        {totalPages > 0 && (
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  className="gap-1"
                >
                  <ChevronLeft className="h-4 w-4" />
                  {t("previous")}
                </Button>
              </PaginationItem>

              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
                if (
                  page === 1 ||
                  page === totalPages ||
                  (page >= currentPage - 1 && page <= currentPage + 1)
                ) {
                  return (
                    <PaginationItem key={page}>
                      <PaginationLink
                        onClick={() => setCurrentPage(page)}
                        isActive={currentPage === page}
                        className="cursor-pointer"
                      >
                        {page}
                      </PaginationLink>
                    </PaginationItem>
                  );
                } else if (page === currentPage - 2 || page === currentPage + 2) {
                  return (
                    <PaginationItem key={page}>
                      <PaginationEllipsis />
                    </PaginationItem>
                  );
                }
                return null;
              })}

              <PaginationItem>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages || totalPages === 0}
                  className="gap-1"
                >
                  {t("next")}
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        )}
      </div>

      {/* Children Dialog */}
      <Dialog open={showChildrenDialog} onOpenChange={setShowChildrenDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {t("childrenOf", { name: `${selectedParent?.profile?.first_name || ""} ${selectedParent?.profile?.last_name || ""}`.trim() })}
            </DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            {selectedParent && selectedParent.children && selectedParent.children.length > 0 ? (
              <div className="space-y-3">
                {selectedParent.children.map((child) => {
                  const fullName = `${child.profile?.first_name || ''} ${child.profile?.last_name || ''}`.trim();
                  const initials = fullName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

                  return (
                    <div
                      key={child.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50"
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-linear-to-r from-[#57A3CC] to-[#022172] flex items-center justify-center text-white font-semibold text-sm">
                          {initials || t("na")}
                        </div>
                        <div>
                          <p className="font-medium">{fullName || t("na")}</p>
                          <p className="text-sm text-muted-foreground">
                            {child.student_number} • {child.grade_level || t("na")}
                          </p>
                          <p className="text-xs text-muted-foreground capitalize">
                            {child.relationship}
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col gap-1 items-end">
                        <Badge className="bg-blue-100 text-blue-800 capitalize">
                          {child.relationship}
                        </Badge>
                        {child.is_emergency_contact && (
                          <Badge variant="outline" className="text-xs">
                            {t("emergencyContact")}
                          </Badge>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">{t("noChildrenAssociated")}</p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* View Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Parent Details</DialogTitle>
          </DialogHeader>
          {selectedParent && (
            <div className="space-y-6">
              {/* Profile Section */}
              <div className="flex items-center gap-4 pb-4 border-b">
                <div className="h-16 w-16 rounded-full bg-linear-to-r from-[#57A3CC] to-[#022172] flex items-center justify-center text-white font-semibold text-xl">
                  {`${selectedParent.profile?.first_name?.[0] || ''}${selectedParent.profile?.last_name?.[0] || ''}`.toUpperCase()}
                </div>
                <div>
                  <h3 className="text-lg font-semibold">
                    {selectedParent.profile?.first_name} {selectedParent.profile?.last_name}
                  </h3>
                  <Badge className={selectedParent.profile?.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                    {selectedParent.profile?.is_active ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </div>

              {/* Contact Information */}
              <div>
                <h4 className="font-semibold mb-3 text-sm text-muted-foreground uppercase tracking-wide">Contact Information</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Email</p>
                    <p className="font-medium">{selectedParent.profile?.email || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Phone</p>
                    <p className="font-medium">{selectedParent.profile?.phone || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">CNIC</p>
                    <p className="font-medium">{selectedParent.cnic || 'N/A'}</p>
                  </div>
                </div>
              </div>

              {/* Professional Information */}
              <div>
                <h4 className="font-semibold mb-3 text-sm text-muted-foreground uppercase tracking-wide">Professional Information</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Occupation</p>
                    <p className="font-medium">{selectedParent.occupation || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Workplace</p>
                    <p className="font-medium">{selectedParent.workplace || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Income</p>
                    <p className="font-medium">{selectedParent.income || 'N/A'}</p>
                  </div>
                </div>
              </div>

              {/* Address Information */}
              <div>
                <h4 className="font-semibold mb-3 text-sm text-muted-foreground uppercase tracking-wide">Address</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <p className="text-sm text-muted-foreground">Street Address</p>
                    <p className="font-medium">{selectedParent.address || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">City</p>
                    <p className="font-medium">{selectedParent.city || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">State</p>
                    <p className="font-medium">{selectedParent.state || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Zip Code</p>
                    <p className="font-medium">{selectedParent.zip_code || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Country</p>
                    <p className="font-medium">{selectedParent.country || 'N/A'}</p>
                  </div>
                </div>
              </div>

              {/* Emergency Contact */}
              {(selectedParent.emergency_contact_name || selectedParent.emergency_contact_phone) && (
                <div>
                  <h4 className="font-semibold mb-3 text-sm text-muted-foreground uppercase tracking-wide">Emergency Contact</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Name</p>
                      <p className="font-medium">{selectedParent.emergency_contact_name || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Relationship</p>
                      <p className="font-medium">{selectedParent.emergency_contact_relation || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Phone</p>
                      <p className="font-medium">{selectedParent.emergency_contact_phone || 'N/A'}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Notes */}
              {selectedParent.notes && (
                <div>
                  <h4 className="font-semibold mb-3 text-sm text-muted-foreground uppercase tracking-wide">Notes</h4>
                  <p className="font-medium whitespace-pre-wrap">{selectedParent.notes}</p>
                </div>
              )}

              {/* Children */}
              <div>
                <h4 className="font-semibold mb-3 text-sm text-muted-foreground uppercase tracking-wide">
                  Children ({selectedParent.children?.length || 0})
                </h4>
                {selectedParent.children && selectedParent.children.length > 0 ? (
                  <div className="space-y-2">
                    {selectedParent.children.map((child) => {
                      const fullName = `${child.profile?.first_name || ''} ${child.profile?.last_name || ''}`.trim();
                      return (
                        <div key={child.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <p className="font-medium">{fullName}</p>
                            <p className="text-sm text-muted-foreground">
                              {child.student_number} • {child.grade_level || 'N/A'}
                            </p>
                          </div>
                          <div className="flex flex-col gap-1 items-end">
                            <Badge className="bg-blue-100 text-blue-800 capitalize text-xs">
                              {child.relationship}
                            </Badge>
                            {child.is_emergency_contact && (
                              <Badge variant="outline" className="text-xs">
                                Emergency Contact
                              </Badge>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-4 border rounded-lg">No children associated</p>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Credentials Modal */}
      {credentialsData && (
        <EditCredentialsModal
          isOpen={showCredentialsModal}
          onClose={() => setShowCredentialsModal(false)}
          entityId={credentialsData.id}
          entityName={credentialsData.name}
          entityType="parent"
          schoolId={schoolId}
          onSuccess={() => { }}
        />
      )}
    </div>
  );
}
