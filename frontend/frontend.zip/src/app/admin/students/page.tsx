import { redirect } from 'next/navigation';

export default function StudentsPage() {
  redirect('/admin/students/student-info');
}
