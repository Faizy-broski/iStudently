import express from 'express'
import * as gradebookController from '../controllers/gradebook.controller'
import { authenticate } from '../middlewares/auth.middleware'
import { requireTeacher, requireAdmin } from '../middlewares/role.middleware'

const router = express.Router()

// All routes require authentication
router.use(authenticate)

// ============================================================================
// ASSIGNMENT TYPES
// ============================================================================

// GET /gradebook/assignment-types?course_period_id=
router.get('/assignment-types', gradebookController.getAssignmentTypes)

// GET /gradebook/assignment-types/course/:courseId
router.get('/assignment-types/course/:courseId', gradebookController.getAssignmentTypesByCourse)

// POST /gradebook/assignment-types (teacher)
router.post('/assignment-types', requireTeacher, gradebookController.createAssignmentType)

// PUT /gradebook/assignment-types/:id (teacher)
router.put('/assignment-types/:id', requireTeacher, gradebookController.updateAssignmentType)

// DELETE /gradebook/assignment-types/:id (teacher)
router.delete('/assignment-types/:id', requireTeacher, gradebookController.deleteAssignmentType)

// ============================================================================
// ASSIGNMENTS
// ============================================================================

// GET /gradebook/assignments?course_period_id=&assignment_type_id=
router.get('/assignments', gradebookController.getAssignments)

// GET /gradebook/assignments/staff (teacher - all assignments for current teacher)
router.get('/assignments/staff', requireTeacher, gradebookController.getAssignmentsByStaff)

// GET /gradebook/assignments/:id
router.get('/assignments/:id', gradebookController.getAssignmentById)

// POST /gradebook/assignments (teacher)
router.post('/assignments', requireTeacher, gradebookController.createAssignment)

// PUT /gradebook/assignments/:id (teacher)
router.put('/assignments/:id', requireTeacher, gradebookController.updateAssignment)

// DELETE /gradebook/assignments/:id (teacher)
router.delete('/assignments/:id', requireTeacher, gradebookController.deleteAssignment)

// POST /gradebook/assignments/mass-create (admin/teacher)
router.post('/assignments/mass-create', requireTeacher, gradebookController.massCreateAssignment)

// ============================================================================
// GRADES
// ============================================================================

// GET /gradebook/grades/assignment/:assignmentId
router.get('/grades/assignment/:assignmentId', gradebookController.getGradesForAssignment)

// GET /gradebook/grades/summary/student/:studentId?marking_period_id=
router.get('/grades/summary/student/:studentId', gradebookController.getStudentGradesSummary)

// GET /gradebook/grades/student/:studentId?course_period_id=
router.get('/grades/student/:studentId', gradebookController.getGradesForStudent)

// POST /gradebook/grades (teacher - single grade entry)
router.post('/grades', requireTeacher, gradebookController.enterGrade)

// POST /gradebook/grades/bulk (teacher - bulk grade entry)
router.post('/grades/bulk', requireTeacher, gradebookController.bulkEnterGrades)

// POST /gradebook/grades/import (teacher - import from CSV/Excel)
router.post('/grades/import', requireTeacher, gradebookController.importGradebookGrades)

// ============================================================================
// CALCULATIONS & VIEWS
// ============================================================================

// GET /gradebook/breakdown?course_period_id=&assignment_id=
router.get('/breakdown', gradebookController.getGradebookBreakdown)

// GET /gradebook/assignment-options?course_period_id=&marking_period_id=
router.get('/assignment-options', gradebookController.getAssignmentOptionsForBreakdown)

// GET /gradebook/view?course_period_id=&section_id= (full gradebook matrix)
router.get('/view', gradebookController.getGradebookView)

// GET /gradebook/average/:studentId?course_period_id=
router.get('/average/:studentId', gradebookController.calculateStudentAverage)

// GET /gradebook/anomalous?course_period_id=&threshold=
router.get('/anomalous', gradebookController.getAnomalousGrades)

// ============================================================================
// CONFIG
// ============================================================================

// GET /gradebook/config?school_id=&course_period_id=
router.get('/config', gradebookController.getConfig)

// POST /gradebook/config (admin)
router.post('/config', requireAdmin, gradebookController.setConfig)

// PUT /gradebook/config (teacher — per-CP overrides only, ownership enforced)
router.put('/config', requireTeacher, gradebookController.setConfigAsTeacher)

// ============================================================================
// PROGRESS REPORTS (batch generation for printing)
// ============================================================================

// POST /gradebook/progress-reports
router.post('/progress-reports', requireAdmin, gradebookController.generateProgressReports)

export default router
